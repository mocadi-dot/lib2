#Les exercices sont en cours de rédaction. Merci d'être patient ! Je galère !
